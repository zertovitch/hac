- CoPascal v2.01 -

This package is a port of the CoPascal compiler/interpreter 
from TurboPascal to Delphi 1 and 3.

CoPascal.pas: Main file for Delphi 1 of the compiler.
CoPascal3.pas: Main file for Delphi 3.

Thses two files uses the same pascal files to compile 
(BlockA.pas, BlockB.pas, BlockC.pas, Header.pas, Init.pas, Insymbol.pas 
and Interpt.pas).

Hello.pas: Test file for the compiler.

Test.bat: This will compile and interpret hello.pas with the Delphi 1 
	  version of the compiler.

Test3.bat: This will compile and interpret hello.pas with the Delphi 3 
	   version of the compiler.

To contact me:
webmaster@bloodshed.nu

Web site:
http://www.bloodshed.nu/