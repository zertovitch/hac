/* Copyright � 1986-1988 by Apple Computer, Inc.  All rights reserved. */
/* Copyright � 1989 by The George Washington University.  All rights reserved. */
/* Macintosh Version by Manuel Perez */
/* Modified: 6/91 by Marcelo Ruiz Camauer */
/*			- add menu items to pick schedulers */


/* Added the following lines for MacApp 2.0b9
 * resources are not included in the command
 * line anymore.
 */
 
#ifndef __TYPES.R__
#include "Types.r"
#endif

#ifndef __SYSTYPES.R__
#include "SysTypes.r"
#endif

#ifndef __MacAppTypes__
#include "MacAppTypes.r"
#endif

#ifndef __ViewTypes__
#include "ViewTypes.r"
#endif


#if qDebug
include "Debug.rsrc";						/* 2.0b8.1 removed MacAppRFiles */
include "Defaults.rsrc"  'dbug' (300);			// Grab the debug window
#endif

include "MacApp.rsrc";
include "Printing.rsrc";
include "Dialog.rsrc";



include "SmallAda" 'CODE';
include "SmallViews.rsrc";
include "Icons.rsrc";



/* Commands */

#define	cHelp			1000
#define	cOptions		1002
#define	cChangeOptions	1004
#define	cCompile		1006
#define	cFirstErr		1007
#define	cLastErr		1009
#define	cNextErr		1008
#define	cPrevErr		1010
#define	cSource			1012
#define	cOutput			1014
#define	cControl		1018
#define	cShowErrors		1020
#define	cHideErrors		1022
#define	cTaskSnapshot	1024
#define	cRuntimeDisplay	1026
#define	cDebugInfo		1028
#define	cSymbolMap		1030
#define	cIdentifiers	1040
/*	#define	cTasks			1042		*/
#define	cEntries		1044
#define	cBlocks			1046
#define	cArrays			1048
#define	cPCode			1050
#define	cGo				1060
#define	cPause			1070
#define	cStep			1080
#define	cStepStep		1085
#define	cReset			1090
#define cClearScreen	1100

/* (MRC) Scheduler to use: */
#define cSched0			1110
#define cSched1			1111
#define cSched2			1112
#define cSched3			1113
#define cSched4			1114
#define cSched5			1115
#define cSched6			1116
#define cSched7			1117



#define cGotoLine		2005
#define cSaveToText		2010
#define cAppendToText	2015
#define cAppendToSame 	2018
#define cImportText		2020
#define	cTaskList		2030
#define	cFirstTaskList	2030
#define	cLastTaskList	cFirstTaskList + TaskMax


#define	cInsertStruct		1019
#define	kBeginEnd			1
#define	kIfThen				2
#define	kIfThenElse			3
#define	kRepeatUntil		4
#define	While				5
#define	kAssign				6
#define	kDeclaration		7
#define	kComments			8


/* Window Ids */

#define	wSource			1000
#define	wOutput			1010
#define	wControl		1030
#define	wEnvironment	1060
#define	wIdentifiers	1040
#define	wTasks			1042
#define	wEntries		1044
#define	wBlocks			1046
#define	wArrays			1048
#define	wPCode			1050

#define kFileTooBig		1040				/* The 'File is too large' alert */
#define kGenericAlert	1999

/* Common buttons and views */

#define iOk				'ok  '
#define iCancel			'cncl'
#define iDialog			'dlog'
#define iWindow			'wind'
#define iText			'text'


#define phSplash		1001			/* ID of splash screen dialog */
#define kStructures		2002


/*	Printing to the LaserWriter is the time when the most temporary memory
	is in use.  We need the segments in use at that time */

resource 'seg!' (256, purgeable) {
	{
		"ASupport";
		"ARunTime";
		"AParser";
		"AParser2";
		"ACodeGen";
		"AScanner";
		"ACompile";
	}
};

/* Resources made resident, never unloaded */
resource 'res!' (256, "Application Segments") {
	{
		"ASupport";
		"ARunTime";
		"AParser";
		"AParser2";
		"ACodeGen";
		"AScanner";
		"ACompile";
	}
};


#ifndef qDebug
resource 'mem!' (256, purgeable) {
	8048,					// Add to temporary reserve
	8048,					// Add to permanent reserve
	10240					// stack space
};
#endif

resource 'SIZE' (-1) {
	saveScreen,
	acceptSuspendResumeEvents,
	enableOptionSwitch,
	canBackground,
	MultiFinderAware,
	backgroundAndForeground,
	dontGetFrontClicks,
	ignoreChildDiedEvents,		/* added the next */
	is32BitCompatible,			/* few lines */
	reserved,
	reserved,
	reserved,
	reserved,
	reserved,
	reserved,
	reserved,
#if qDebug
	700 * 1024,
	700 * 1024
#else
	650 * 1024,
	650 * 1024
#endif
};

resource 'DITL' (201, "About Box Items", purgeable) {
	{
		{229, 154, 249, 234}, Button { enabled, "OK" },
		{0, 2, 221, 416}, Picture { disabled, 1001 }
	}
};

resource 'DLOG' (201, "About Box", purgeable, preload) {
	{76, 80, 340, 496},
	noGrowDocProc, visible, goAway, 0x0, 201,
	"About Small Ada"
};


resource 'ALRT' (201, purgeable) {
	{90, 100, 280, 412},
	201,
	{
		OK, visible, silent;
		OK, visible, silent;
		OK, visible, silent;
		OK, visible, silent
	}
};

resource 'cmnu' (1) {
	1,
	textMenuProc,
	0x7FFFFFFD,
	enabled,
	apple,
	 {
		"About SmallAda�", noIcon, noKey, noMark, plain, cAboutApp;
/**		"Help�", noIcon, noKey, noMark, plain, cHelp;	**/
		"-", noIcon, noKey, noMark, plain, nocommand
	}
};

resource 'cmnu' (2) {
	2,
	textMenuProc,
	0x7FFFFBBB,
	enabled,
	"File",
	 {
	 	"New", noIcon, "N", noMark, plain, cNew;
		"Open�", noIcon, "O", noMark, plain, cOpen;
		"-", noIcon, noKey, noMark, plain, nocommand;
		"Close", noIcon, "W", noMark, plain, cClose;
		"Save", noIcon, "S", noMark, plain, cSave;
		"Save As�", noIcon, noKey, noMark, plain, cSaveAs;
		"Save a Copy In�", noIcon, noKey, noMark, plain, cSaveCopy;
		"-", noIcon, noKey, noMark, plain, nocommand;
		"Import Text�", noIcon, noKey, noMark, plain, cImportText;
		"Export Text�", noIcon, noKey, noMark, plain, cSaveToText;
		"Append To�", noIcon, noKey, noMark, plain, cAppendToText;
/**		"Append To Same", noIcon, noKey, noMark, plain, cAppendToSame; **/
		"-", noIcon, noKey, noMark, plain, nocommand;
		"Page Setup�", noIcon, noKey, noMark, plain, cPageSetup;
		"Print�", noIcon, "P", noMark, plain, cPrint;
		"-", noIcon, noKey, noMark, plain, nocommand;
		"Quit", noIcon, "Q", noMark, plain, cQuit
	}
};

resource 'cmnu' (3) {
	3,
	textMenuProc,
	0x7FFFFFBD,
	enabled,
	"Edit",
	 {	
		"Undo", noIcon, "Z", noMark, plain, cUndo;
		"-", noIcon, noKey, noMark, plain, nocommand;
		"Cut", noIcon, "X", noMark, plain, cCut;
		"Copy", noIcon, "C", noMark, plain, cCopy;
		"Paste", noIcon, "V", noMark, plain, cPaste;
		"Clear", noIcon, "B", noMark, plain, cClear;
		"Select All", noIcon, "A", noMark, plain, cSelectAll;
		"-", noIcon, noKey, noMark, plain, nocommand;
		"Show Clipboard", noIcon, noKey, noMark, plain, cShowClipboard;
		"-", noIcon, noKey, noMark, plain, nocommand;
		"Options�", noIcon, noKey, noMark, plain, cOptions
	}
};

resource 'cmnu' (4) {
	4,
	textMenuProc,
	0x7FFFFFBD,
	enabled,
	"Source",
	 {	
		"Compile�", noIcon, "K", noMark, plain, cCompile;
		"-", noIcon, noKey, noMark, plain, nocommand;
		"First Error", noIcon, "F", noMark, plain, cFirstErr;
		"Next Error", noIcon, "I", noMark, plain, cNextErr;
		"Previous Error", noIcon, "J", noMark, plain, cPrevErr;
		"Last Error", noIcon, "L", noMark, plain, cLastErr;
/**		"Show Symbol Map", noIcon, noKey, noMark, plain, cSymbolMap;	**/
/**		"Show Debug Info", noIcon, noKey, noMark, plain, cDebugInfo;	**/
/**		"Task Snapshot", noIcon, noKey, noMark, plain, cTaskSnapshot;	**/
		"-", noIcon, noKey, noMark, plain, nocommand;
		"Goto Line #�", noIcon, noKey, noMark, plain, cGotoLine;
	}
};

resource 'cmnu' (5) {
	5,
	textMenuProc,
	0x7FFFFFBD,
	enabled,
	"Run",
	 {
		"Go", noIcon, "G", noMark, plain, cGo;
		"Step", noIcon, "T", noMark, plain, cStep;
		"Pause", noIcon, ".", noMark, plain, cPause;
/**		"Step-Step", noIcon, noKey, noMark, plain, cStepStep;	**/
		"-", noIcon, noKey, noMark, plain, nocommand;
		"Reset", noIcon, "R", noMark, plain, cReset;
		"-", noIcon, noKey, noMark, plain, nocommand;
		"Clear Terminal", noIcon, noKey, noMark, plain, cClearScreen;
		"Run Time Display", noIcon, noKey, noMark, plain, cRuntimeDisplay;

	}
};


resource 'cmnu' (6) {
	6,
	textMenuProc,
	0x7FFFFFBD,
	enabled,
	"Windows",
	 {	
		"Source", noIcon, "1", noMark, plain, cSource;
		"Terminal", noIcon, "2", noMark, plain, cOutput;
		"Control", noIcon, "3", noMark, plain, cControl;
		"Errors", noIcon, "4", noMark, plain, cShowErrors;
		"-", noIcon, noKey, noMark, plain, nocommand,
		"Identifiers", noIcon, "5", noMark, plain, cIdentifiers;
		"Entries", noIcon, "6", noMark, plain, cEntries;
		"Blocks", noIcon, "7", noMark, plain, cBlocks;
		"Arrays", noIcon, "8", noMark, plain, cArrays;
		"P-Code", noIcon, "9", noMark, plain, cPCode;
	}		/* 8 is the maximum allowed for tasks (see constant TaskMax) */
};

/****
		"-", noIcon, noKey, noMark, plain, nocommand;
		"Task 1", noIcon, noKey, noMark, plain, cTaskList;
		"Task 2", noIcon, noKey, noMark, plain, cTaskList + 1;
		"Task 3", noIcon, noKey, noMark, plain, cTaskList + 2;
		"Task 4", noIcon, noKey, noMark, plain, cTaskList + 3;
		"Task 5", noIcon, noKey, noMark, plain, cTaskList + 4;
		"Task 6", noIcon, noKey, noMark, plain, cTaskList + 5;
		"Task 7", noIcon, noKey, noMark, plain, cTaskList + 7;
		"Task 8", noIcon, noKey, noMark, plain, cTaskList + 8
****/

resource 'cmnu' (7) {
	7,
	textMenuProc,
	0x7FFFFFBD,
	enabled,
	"Scheduler",
	 {
		"Dynamic Priority (using Elapsed Time)", noIcon, noKey, noMark, plain, cSched0;
		"Run Until Blocked", noIcon, noKey, noMark, plain, cSched1;
		"Round Robin using Time Slicing", noIcon, noKey, noMark, plain, cSched2;
		"Preemptive Static Priority without Time Slicing", noIcon, noKey, noMark, plain, cSched3;
		"Preemptive Static Priority with Time Slicing (lexical order)", noIcon, noKey, noMark, plain, cSched4;
		"Nonpreemptive Static Priority with Time Slicing (lexical order)", noIcon, noKey, noMark, plain, cSched5;
		"Preemptive Static Priority with Time Slicing (lexical order)", noIcon, noKey, noMark, plain, cSched6;
		"Nonpreemptive Static Priority without Time Slicing (lexical order)", noIcon, noKey, noMark, plain, cSched7;

	}
};


resource 'cmnu' (128) {
	128,
	textMenuProc,
	allEnabled,
	enabled,
	"Buzzwords",
	 {
		"Hide Errors", noIcon, noKey, noMark, plain, cHideErrors;
		"Page Setup Change", noIcon, noKey, noMark, plain, cChangePrinterStyle;
		"Source Format Change", noIcon, noKey, noMark, plain, cChangeOptions;
		"Insert", noIcon, noKey, noMark, plain, cInsertStruct
	}
};

resource 'MBAR' (128) {
	{1; 2; 3; 4; 7; 5; 6}
};



/*--------------------------------------------------------------------------------
 Splash screen
--------------------------------------------------------------------------------*/
resource 'DITL' (phSplash,
#if qNames
"phSplash",
#endif
	purgeable, preload) {
	{	/* array DITLarray: 1 elements */
		/* [1] */
		{1, 1, 432-211+1, 437-23+1},
		Picture {
			disabled,
			phSplash
		}
	}
};

resource 'DLOG' (phSplash,
#if qNames
"phSplash",
#endif
	purgeable, preload) {
	{76, 80, 432-211+76+2, 437-23+80+2},
	altDBoxProc,
	visible,
	noGoAway,
	0,
	phSplash,
	""
};



/* Used when the user attempts to read a file larger than we can handle */

resource 'DITL' (kFileTooBig, purgeable) {
	{
/* [ 1] */	{82, 198, 100, 272}, Button { enabled, "OK" };
/* [ 2] */	{10, 70, 77, 272}, StaticText { disabled,
				"SmallAda can�t read the entire file because it is too long."
			};
/* [ 3] */	{10, 20, 42, 52}, Icon { disabled, 0 }
	}
};

resource 'ALRT' (kFileTooBig, purgeable) {
	{100, 110, 210, 402},
	kFileTooBig,
	{
/* [ 1] */	OK, visible, silent;
/* [ 2] */	OK, visible, silent;
/* [ 3] */	OK, visible, silent;
/* [ 4] */	OK, visible, silent
	}
};



resource 'DITL' (kGenericAlert, purgeable) {
	{
/* [ 1] */	{82, 198, 100, 272}, Button { enabled, "OK" };
/* [ 2] */	{10, 70, 77, 272}, StaticText { disabled,
				"^0^1^2^3"
			};
/* [ 3] */	{10, 20, 42, 52}, Icon { disabled, 0 }
	}
};

resource 'ALRT' (kGenericAlert, purgeable) {
	{100, 110, 210, 402},
	kGenericAlert,
	{
/* [ 1] */	OK, visible, silent;
/* [ 2] */	OK, visible, silent;
/* [ 3] */	OK, visible, silent;
/* [ 4] */	OK, visible, silent
	}
};

resource 'MENU' (64) {
	64,
	textMenuProc,
	0x7FFFFFFF,
	enabled,
	"",
	 {	
		"Program", noIcon, noKey, noMark, plain;
		"Task Spec.", noIcon, noKey, noMark, plain;
		"Task Body", noIcon, noKey, noMark, plain;
		"Procedure", noIcon, noKey, noMark, plain;
		"Function", noIcon, noKey, noMark, plain;
		"If Then End If", noIcon, noKey, noMark, plain;
		"If Then Else End If", noIcon, noKey, noMark, plain;
		"For Loop�End Loop", noIcon, noKey, noMark, plain;
		"While", noIcon, noKey, noMark, plain;
		"Loop�End Loop", noIcon, noKey, noMark, plain;
		"Comments", noIcon, noKey, noMark, plain
	}
};

resource 'STR#' (kStructures, purgeable) {
	 {
		"-- Your Comments\n"
		"WITH Small_Sp; USE Small_Sp;\n"
		"PROCEDURE <name> IS\n"
		"BEGIN\n"
		"	null;\n"
		"END <name>;\n";

		"TASK <taskName> IS\n"
		"	ENTRY <entryName>\n"
		"END <taskName>;\n";

		"TASK BODY <taskName> IS\n"
		"BEGIN\n"
		"	null;\n"
		"END <taskName>;\n";

		"PROCEDURE <name> IS\n"
		"BEGIN\n"
		"	null;\n"
		"END <name>;\n";

		"FUNCTION  <functionName> RETURN <type> IS\n"
		"BEGIN\n"
		"	null;\n"
		"	RETURN <value>;\n"
		"END <functionName>;\n";

		"IF <condition> THEN\n"
		"	null;\n"
		"END IF;\n";

		"IF <condition> THEN\n"
		"	null;\n"
		"ELSE\n"
		"	null;\n"
		"END IF;\n";


		"FOR i IN <range> LOOP\n"
		"	null;\n"
		"END LOOP;\n";

		"WHILE <boolean_expression> LOOP\n"
		"	null;\n"
		"END LOOP;\n";

		"LOOP\n"
		"	null;\n"
		"	EXIT WHEN <boolean_expression>\n"
		"END LOOP;\n";

		"--"
	 }
};



resource 'STR#' (5000,
#if qNames
	"kDefaultCredits",
#endif
	purgeable) {
	 {
	"The great people behind SmallAda�";

	"Engineers and philosophers�";
	"Michael B. Feldman";
	"Manuel A. P�rez";
	"Arthur Vargas Lopes";
	"Frederick C. Hathorn";
	"Stuart Cramer";
	"Jay Kurtz";
	"Oguz Tumer";
	"Marcelo Ruiz-Camau�r";

	"Technical support past and present�";
	"Chuck McMath";
	"Clarus� the DogCow� (Moof�!)"


	 }
};


resource 'STR#' (1000,  "Error Messages") {
	{
		/*  0 */ "UNDEFINED IDENTIFIER";
		/*  1 */ "MULTIPLE DEFINITION OF AN IDENTIFIER";
		/*  2 */ "MISSING AN IDENTIFIER";
		/*  3 */ "MISSING A PROCEDURE DECLARATION";
		/*  4 */ "MISSING CLOSING PARENTHESIS �)�";
		/*  5 */ "MISSING A COLON �:�";
		/*  6 */ "INCORRECTLY USED SYMBOL";
		/*  7 */ "MISSING IDENTIFIER";
		/*  8 */ "MISSING �OF�";
		/*  9 */ "MISSING AN OPENING PARENTHESIS �)�";
		/* 10 */ "MISSING IDENTIFER; �ARRAY� OR �RECORD�";
		/* 11 */ "-- OPENING BRACKET �[�";
		/* 12 */ "-- CLOSING BRACKET �]�";
		/* 13 */ "EXPECTING �..�";
		/* 14 */ "MISSING A SEMICOLON �;�";
		/* 15 */ "BAD RESULT TYPE FOR A FUNCTION";
		/* 16 */ "ILLEGAL STATEMENT START SYMBOL";
		/* 17 */ "EXPECTING A BOOLEAN EXPRESSION ";
		/* 18 */ "CONTROL VARIABLE OF THE WRONG TYPE";
		/* 19 */ "FIRST/LAST MUST BE MATCHING TYPES";
		/* 20 */ "MISSING �IS�";
		/* 21 */ "THE NUMBER IS TOO LARGE";
		/* 22 */ "INCORRECT BLOCK NAME";
		/* 23 */ "BAD TYPE FOR A CASE STATEMENT";
		/* 24 */ "ILLEGAL CHARACTER";
		/* 25 */ "ILLEGAL CONSTANT OR CONSTAT IDENTIFIER";
		/* 26 */ "ILLEGAL ARRAY SUBSCRIPT (CHECK TYPE)";
		/* 27 */ "ILLEGAL BOUNDS FOR AN ARRAY INDEX";
		/* 28 */ "INDEXED VARIABLE MUST BE AN ARRAY";
		/* 29 */ "MISSING A TYPE IDENFIFIER";
		/* 30 */ "UNDEFINED TYPE";
		/* 31 */ "VAR WITH FIELD SELECTOR MUST BE RECORD";
		/* 32 */ "RESULTING TYPE IS NOT �BOOLEAN�";
		/* 33 */ "ILLEGAL TYPE FOR ARITHMETIC EXPRESSION";
		/* 34 */ "�MOD� REQUIRES INTEGER ARGUMENTS";
		/* 35 */ "INCOMPATIBLE TYPES FOR COMPARISON";
		/* 36 */ "PARAMETER TYPES DO NOT MATCH";
		/* 37 */ "MISSING A VARIABLE";
		/* 38 */ "A STRING MUST HAVE ONE OR MORE CHAR";
		/* 39 */ "NUMBER OF PARAMETERS DO NOT MATCH";
		/* 40 */ "ILLEGAL PARAMETERS TO �GET�";
		/* 41 */ "ILLEGAL PARAMETERS TO �PUT�";
		/* 42 */ "PARAMETER MUST BE OF TYPE �FLOAT�";
		/* 43 */ "PARAMETER MUST BE OF TYPE �INTEGER�";
		/* 44 */ "EXPECTED A VARIABLE; FUNCTION OR CONST";
		/* 45 */ "ILLEGAL RETURN STATEMENT FROM MAIN";
		/* 46 */ "TYPES MUST MATCH IN AN ASSIGNMENT";
		/* 47 */ "CASE LABEL NOT SAME TYPE AS CASE CLAUSE";
		/* 48 */ "ARGUMENT TO STD. FUNCTION OF WRONG TYPE";
		/* 49 */ "THE PROGRAM REQUIRES TOO MUCH STORAGE";
		/* 50 */ "ILLEGAL SYMBOL FOR A CONSTANT";
		/* 51 */ "MISSING �:=�";
		/* 52 */ "MISSING �THEN�";
		/* 53 */ "MISSING �IN�";
		/* 54 */ "MISSING �LOOP�";
		/* 55 */ "MISSING RANGE �..�";
		/* 56 */ "MISSING �BEGIN�";
		/* 57 */ "MISSING �END�";
		/* 58 */ "EXPECTING AN ID; CONST; �NOT� OR �(�";
		/* 59 */ "MISSING �RETURN�";
		/* 60 */ "CONTROL CHARACTER PRESENT IN SOURCE ";
		/* 61 */ "MISSING �RECORD�";
		/* 62 */ "MISSING CLOSING �IF�";
		/* 63 */ "MISSING �WHEN�";
		/* 64 */ "MISSING the finger �=>�";
		/* 65 */ "MISSING CLOSING �CASE�";
		/* 66 */ "CHARACTER DELIMETER USED FOR STRING";
		/* 67 */ "Ada RESERVED WORD; NOT SUPPORTED";
		/* 68 */ "FUNCTIONS MUST RETURN A VALUE";
		/* 69 */ "MUST SPECIFY �WITH SMALL_SP;�";
		/* 70 */ "MUST SPECIFY �USE SMALL_SP;�";
		/* 71 */ "EXPECTING AN ENTRY";
		/* 72 */ "MISSING EXPRESSION FOR DELAY";
		/* 73 */ "DELAY TIME MUST BE TYPE FLOAT";
		/* 74 */ "COMMA EXPECTED";
		/* 75 */ "PARAMETER MUST BE OF TYPE �BOOLEAN�";
		/* 76 */ "EXPECTING �ACCEPT�; �WHEN�; OR ENTRY ID";
		/* 77 */ "EXPECTING Task.Entry";
		/* 78 */ "EXPECTING �OR� OR �ELSE� IN SELECT";
		/* 79 */ "EXPECTING �DELAY�";
		/* 80 */ "MISSING SELECT";
		/* 81 */ "PROGRAM INCOMPLETE";
		/* 82 */ " ";
		/* 83 */ " ";
		/* 84 */ " ";
		/* 85 */ " ";
		/* 86 */ " ";
		/* 87 */ " ";
		/* 88 */ " ";
		/* 89 */ " ";
		/* 90 */ " ";
	};
};


resource 'STR#' (1001,  "P-Code Instructions") {
	{
	 /* 0 */ "LoadAddress";
	 /* 1 */ "LoadValue";
	 /* 2 */ "LoadIndirect";
	 /* 3 */ "UpdateDisplay";
	 /* 4 */ "AcceptRendezvous";
	 /* 5 */ "EndRendezvous";
	 /* 6 */ "Wait";
	 /* 7 */ "Signal";
	 /* 8 */ "StndFunctions";
	 /* 9 */ "Offset";
	/* 10 */ "Jump";
	/* 11 */ "CondJump";
	/* 12 */ "Switch";
	/* 13 */ "Noop13?";
	/* 14 */ "For";
	/* 15 */ "End For";
	/* 16 */ "For Reverse";
	/* 17 */ "End For Reverse";
	/* 18 */ "MarkStack";
	/* 19 */ "Call";
	/* 20 */ "Index1";
	/* 21 */ "Index";
	/* 22 */ "LoadBlock";
	/* 23 */ "CopyBlock";
	/* 24 */ "LoadLiteral";
	/* 25 */ "LoadFloat";
	/* 26 */ "Float(X)";
	/* 27 */ "Read";
	/* 28 */ "WriteString";
	/* 29 */ "Write1";
	/* 30 */ "Write2";
	/* 31 */ "Noop31?";
	/* 32 */ "ExitCall";
	/* 33 */ "ExitFunction";
	/* 34 */ "Case34";
	/* 35 */ "NOT";
	/* 36 */ "Negate";
	/* 37 */ "Write Float";
	/* 38 */ "Store";
	/* 39 */ "Float =";
	/* 40 */ "Float <>";
	/* 41 */ "Float <";
	/* 42 */ "Float <=";
	/* 43 */ "Float >";
	/* 44 */ "Float >=";
	/* 45 */ "Integer =";
	/* 46 */ "Integer <>";
	/* 47 */ "Integer <";
	/* 48 */ "Integer <=";
	/* 49 */ "Integer >";
	/* 50 */ "Integer >=";
	/* 51 */ "OR";
	/* 52 */ "Integer +";
	/* 53 */ "Integer -";
	/* 54 */ "Real +";
	/* 55 */ "Real -";
	/* 56 */ "AND";
	/* 57 */ "Integer *";
	/* 58 */ "DIV";
	/* 59 */ "MOD";
	/* 60 */ "Real *";
	/* 61 */ "Real /";
	/* 62 */ "GetNewline";
	/* 63 */ "PutNewline";
	/* 64 */ "SetCurrFilePtr";
	/* 65 */ "File_I_O";
	/* 66 */ "Halt";
	/* 67 */ "StrAssignment";
	/* 68 */ "Delay";
	/* 69 */ "CursorAt";
	/* 70 */ "SetQuatumTask";
	/* 71 */ "SetTskPrio";
	/* 72 */ "SetTskPrioInhtance";
	/* 73 */ "SelectiveWait";
	/* 74 */ "HighlightSrc";
	};
};


resource 'STR#' (1002,  "Identifier Table Headers") {
	{
	 /* 1 */ "";
	 /* 2 */ "Identifiers";
	 /* 3 */ "Link";
	 /* 4 */ "Object?";
	 /* 5 */ "Type";
	 /* 6 */ "Ref";
	 /* 7 */ "Nrm";
	 /* 8 */ "Lev";
	 /* 9 */ "Adr";
	};
};


resource 'STR#' (1003,  "Task header") {
	{
	 /* 1 */ " Task Name";
	 /* 2 */ "State";
	 /* 3 */ " PC";
	 /* 4 */ "CalcPri";
	 /* 5 */ "UsrPri";
	};
};

resource 'STR#' (1004,  "PCode header") {
	{
	 /* 1 */ "";
	 /* 2 */ "Opcode";
	 /* 3 */ "IR.X";
	 /* 4 */ "IR.Y";
	};
};


resource 'STR#' (1005,  "Blocks header") {
	{
	 /* 1 */ " #";
	 /* 2 */ "Block Name";
	 /* 3 */ "Last";
	 /* 4 */ "LPar";
	 /* 5 */ "PSze";
	 /* 6 */ "VSze";
	 /* 7 */ "SrcF";
	 /* 8 */ "SrcT";
	};
};

resource 'STR#' (1006,  "Error header") {
	{
	 /* 1 */ " Line Error  Error Message";
	};
};

resource 'STR#' (1008,  "Arrays header") {
	{
	 /* 1 */ " #";
	 /* 2 */ "Xtyp";
	 /* 3 */ "Element Type";
	 /* 4 */ "ERef";
	 /* 5 */ "Low";
	 /* 6 */ "High";
	 /* 7 */ "ESiz";
	 /* 8 */ "Size";
	};
};

/* Wait while compiling */
resource 'DITL' (1000) {
	{
		{16,  42, 37, 302}, StaticText { disabled, "^0" },	/* Message */
		{40,  42, 55, 302}, StaticText { disabled, "" },	/* box */
		{63,  42, 84,  62}, StaticText { disabled, "0" },	/* 0 */
		{63, 262, 84, 302}, StaticText { disabled, "^1" },	/* total lines */
		{63, 152, 84, 188}, StaticText { disabled, "Lines" }/* lines */
/***
		{63, 42, 84, 302}, StaticText { disabled,
			"Press \0x11-. (Command-period) to Cancel."}
***/
	}
};

resource 'DLOG' (1000) {
	{40, 40, 140, 360}, dBoxProc, visible, noGoAway,
	0x0, 1000, "Compiling"
};

type 'SAda' as 'STR ';
resource 'SAda' (0, purgeable) {
	"SmallAda created by Manuel A. P�rez"
};

resource 'FREF' (128, purgeable) { 'APPL', 0, "" };
resource 'FREF' (129, purgeable) { 'TEXT', 1, "" };

resource 'BNDL' (128, purgeable) {
	'SAda', 0, {
		'ICN#', { /* local resource ID mapping for icons */
			0, 128,		/* Application */
			1, 129		/* Text Document */
		},
		'FREF', { /* local resource ID mapping for file type references */
			0, 128,		/* Application (APPL) */
			1, 129		/* Text Document */
		},

	}
};

// Version for the "application or file"
resource 'vers' (1, purgeable) {
	0x01, 0x00, release, 0x01, verUs,
	"1.0",
	"1.0 GWU Small Ada"
};

// Version for the "package"
resource 'vers' (2, purgeable) {
	0x01, 0x00, beta, 0x02, verUs,
	"1.0b2",
	"1.0b2 Small Ada"
};



/* Views that seem to be stable */

/* Icon: 0 = mano, 1 = boca, 2 = Warning (!) */
/* CIcn: 5 = bomb, 4 = pirate skull, */
resource 'view' (2000, "YesNo", purgeable) {{

	root, 'wind', {50, 40}, {72, 328}, sizeVariable, sizeVariable, shown, enabled, 
	Window {"TWindow", dBoxProc, noGoAwayBox, notResizable, modal, ignoreFirstClick, 
		dontFreeOnClosing, disposeOnFree, closesDocument, openWithDocument, 
		dontAdaptToScreen, dontStagger, dontForceOnScreen, center, 'dlog', "<<<>>>"}, 

	'wind', 'dlog', {0, 0}, {72, 328}, sizeVariable, sizeVariable, shown, enabled, 
	DialogView {"TDialogView", 'ok  ', 'cncl'}, 

	'dlog', 'icon', {16, 8}, {32, 32}, sizeFixed, sizeFixed, shown, disabled, 
	Icon {"TIcon", noAdornment, sizeable, notDimmed, notHilited, 
		doesntDismiss, noInset, systemFont, preferColor, 2}, 

	'dlog', 'text', {16, 56}, {40, 192}, sizeFixed, sizeFixed, shown, disabled, 
	StaticText {"TStaticText", noAdornment, sizeable, notDimmed, notHilited, 
		doesntDismiss, noInset, applFont9, justLeft, ""}, 

	'dlog', 'ok  ', {8, 256}, {24, 64}, sizeFixed, sizeFixed, shown, enabled, 
	Button {"TButton", adnRRect, {3, 3}, sizeable, notDimmed, notHilited, 
		dismisses, {4, 4, 4, 4}, systemFont, "Yes"}, 

	'dlog', 'cncl', {40, 256}, {24, 64}, sizeFixed, sizeFixed, shown, enabled, 
	Button {"TButton", noAdornment, sizeable, notDimmed, notHilited, 
		dismisses, {4, 4, 4, 4}, systemFont, "No"}
	}
};

/* Options dialog */
resource 'view' (1080, "Options", purgeable) {{

	root, 'wind', {50, 40}, {248, 288}, sizeVariable, sizeVariable, shown, enabled, 
	Window {"TWindow", dBoxProc, noGoAwayBox, notResizable, modal, ignoreFirstClick, 
		dontFreeOnClosing, disposeOnFree, closesDocument, openWithDocument, 
		dontAdaptToScreen, dontStagger, forceOnScreen, center, 'dlog', "<<<>>>"}, 

	'wind', 'dlog', {0, 0}, {248, 288}, sizeVariable, sizeVariable, shown, enabled, 
	DialogView {"TDialogView", 'ok  ', 'cncl'}, 

	'dlog', 'VW01', {64, 16}, {72, 256}, sizeFixed, sizeFixed, shown, disabled, 
	Cluster {"TCluster", noAdornment, sizeable, notDimmed, notHilited, 
		doesntDismiss, noInset, systemFont, "Error display"}, 

	'VW01', 'line', {16, 8}, {16, 240}, sizeFixed, sizeFixed, shown, enabled, 
	Radio {"TRadio", noAdornment, sizeable, notDimmed, notHilited, 
		doesntDismiss, noInset, systemFont, off, "Select source line"}, 

	'VW01', 'tokn', {32, 8}, {16, 240}, sizeFixed, sizeFixed, shown, enabled, 
	Radio {"TRadio", noAdornment, sizeable, notDimmed, notHilited, 
		doesntDismiss, noInset, systemFont, off, "Select offending token"}, 

	'VW01', 'inst', {48, 8}, {16, 240}, sizeFixed, sizeFixed, shown, enabled, 
	Radio {"TRadio", noAdornment, sizeable, notDimmed, notHilited, 
		doesntDismiss, noInset, systemFont, off, "Set insertion point"}, 

	'dlog', 'open', {40, 16}, {16, 256}, sizeFixed, sizeFixed, shown, enabled, 
	CheckBox {"TCheckBox", noAdornment, sizeable, notDimmed, notHilited, 
		doesntDismiss, noInset, systemFont, off, "Automatically open error window"}, 

	'dlog', 'VW07', {8, 16}, {24, 256}, sizeFixed, sizeFixed, shown, disabled, 
	StaticText {"TStaticText", noAdornment, sizeable, notDimmed, notHilited, 
		doesntDismiss, noInset, 1, 14, black, "A", justLeft, "Options"}, 

	'dlog', 'ok  ', {208, 192}, {24, 80}, sizeFixed, sizeFixed, shown, enabled, 
	Button {"TButton", adnRRect, {3, 3}, sizeable, notDimmed, notHilited, 
		dismisses, {4, 4, 4, 4}, systemFont, "OK"}, 

	'dlog', 'cncl', {208, 16}, {24, 80}, sizeFixed, sizeFixed, shown, enabled, 
	Button {"TButton", noAdornment, sizeable, notDimmed, notHilited, 
		dismisses, noInset, systemFont, "Cancel"}, 

	'dlog', 'VW02', {152, 16}, {16, 248}, sizeFixed, sizeFixed, shown, enabled, 
	CheckBox {"TCheckBox", noAdornment, sizeable, notDimmed, notHilited, 
		doesntDismiss, noInset, applFont9, on, "Automatically open Terminal Window when ""running"}, 

	'dlog', 'VW03', {176, 16}, {16, 248}, sizeFixed, sizeFixed, shown, enabled, 
	CheckBox {"TCheckBox", noAdornment, sizeable, notDimmed, notHilited, 
		doesntDismiss, noInset, applFont9, off, "Automatically open Control Panel when ru""nning"}
	}
};




#define errAppTable				1000
#define appErrReasons			2001
#define appErrRecovery			2004
#define appErrOperations		2003

/* Error Operations description - map from the loWd of the */
/* msgLookup or msgAltRecovery to a string. */
resource 'errs' (errAppTable + errOperationsID, purgeable) {
	{	whichList, 0, appErrOperations;
		1, 1, 1;				/* create control window */
		2, 2, 2;				/* say not to bugs */
		3, 3, 3;				/* we made it here */
	}
};

resource 'STR#' (appErrOperations, purgeable) {
	{
		/* [1] */	"create the control window";
		/* [2] */	"bug you";
		/* [3] */	"make it run";
	}
};


/* Error Explanations (reasons) - map from an error code */
/* to a string stored in appErrReasons.  Use the third integer */
/* in a line as the index in to the STR# resource */
resource 'errs' (errAppTable + errReasonID, purgeable) {
	{	whichList, 0, appErrReasons;
		-25000, -25000, 2;		/* errors */
		-25001, -25001, 3;		/* more errors */
		-25010, -25010, 4;
		minErr, maxErr, 1
	}
};

/* Could not do something because ^0 */
resource 'STR#' (appErrReasons, purgeable) {
	{
		/* [1] */	"of some weird error";		/* catch-all */
		/* [2] */	"of some weird error";
		/* [3] */	"reason -25101:-25200";
		/* [4] */	"general message";
	}
};



/* Error recovery descriptions - map from a loWd whenever */
/* the msgAltRecovery hiWd is used.  Otherwise map from */
/* an errCode if the msgLookup hiWd is used. */
resource 'errs' (errAppTable + errRecoveryID, purgeable) {
	{	whichList, 0, appErrRecovery;

		/* msgAltRecovery : loWd messages */
		1, 1, 3;				/* we made it here */
		1, 2, 3;				/* we made it here */

		/* msgLookup : Error codes */
		-25000, -25000, 3;		/* recovery */
		-25101, -25200, 2;		/* more recovery */
	}
};

resource 'STR#' (appErrRecovery, purgeable) {
	{
		/* [1] */	"Please contact your support representative.";
		/* [2] */	"Just say no to Bugs.";
		/* [3] */	"You will have to use the system without it.";
	}
};

